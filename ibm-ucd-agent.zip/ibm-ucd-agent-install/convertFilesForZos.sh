#!/bin/sh
# This shell script converts the necessary files to IBM-1047 for installing on z/OS

convert_file () {
    iconv -f "utf-8" -t "ibm-1047" $1 > tmp
    mv tmp $1
}

convert_file install-agent.sh
convert_file install.with.groovy.xml
convert_file opt/apache-ant-1.8.4/bin/ant
convert_file opt/apache-ant-1.8.4/bin/antRun
convert_file opt/groovy-1.8.8/bin/groovy
convert_file opt/groovy-1.8.8/bin/startGroovy
convert_file install/AgentInstaller.groovy
